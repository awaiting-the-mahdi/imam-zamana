# Awaiting the Mahdi — website

A responsive, single-page website starter for an educational Imam-e-Zamana (atfs) project.

## Run locally
Open `index.html` in a browser. No build tools, dependencies, or account required.

## Features
- Responsive layout for mobile and desktop
- Books section with interactive reading-note modals
- Search overlay
- Light/dark theme toggle
- Mobile navigation menu
- Hadith/source citation guidance
- Accessible labels and keyboard Escape-to-close behavior

## Publish free
### GitHub Pages
1. Create a GitHub repository and upload `index.html`.
2. Open the repository's **Settings → Pages**.
3. Under **Build and deployment**, select **Deploy from a branch**.
4. Choose `main` and `/ (root)`, then save.
5. GitHub will show the published URL after deployment.

### Netlify Drop
You can also upload the folder to Netlify's manual deploy/drop workflow. Check the provider's current free-plan terms.

## Content accuracy note
The site intentionally avoids claiming that unsourced quotes are authenticated and does not invent volume/page numbers. Verify the exact Arabic, translation, source, edition and any grading before publishing hadith content. Book descriptions are starter copy; confirm publication details against the editions you use.
